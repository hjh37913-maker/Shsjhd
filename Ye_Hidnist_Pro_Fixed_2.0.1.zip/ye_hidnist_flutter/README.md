# Є-Гідність Pro Flutter

Професійний локальний демонстраційний Flutter-додаток цифрового простору школи.

## Виправлено у 2.0.1
- Flutter entry point переведено на єдину Riverpod-архітектуру.
- Додано відсутні залежності `flutter_riverpod`, `go_router`, `hive_flutter`, `google_fonts` та інші залежності, які реально використовуються кодом.
- Hive ініціалізується до запуску застосунку.
- Демонстраційні локальні дані автоматично створюються при першому запуску.
- GitHub Actions винесено у кореневий `.github/workflows`, тому GitHub гарантовано бачить workflow.
- Workflow виконує Flutter-команди всередині `ye_hidnist_flutter`.
- APK перевіряється перед завантаженням artifact.

## Збірка локально
```bash
cd ye_hidnist_flutter
flutter pub get
flutter create --platforms=android .
flutter build apk --release
```

APK:
`ye_hidnist_flutter/build/app/outputs/flutter-apk/app-release.apk`

## Важливо
QR, Дія та сканування тут є локальними демонстраційними сценаріями. Реальна інтеграція з державними або шкільними backend/API потребує окремої серверної частини, API-ключів та юридичної інтеграції.
